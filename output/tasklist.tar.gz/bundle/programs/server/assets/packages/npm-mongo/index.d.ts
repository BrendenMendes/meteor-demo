import * as NpmModuleMongodb from 'mongodb';
declare const NpmModuleMongodbVersion: string;
export { NpmModuleMongodb, NpmModuleMongodbVersion };
